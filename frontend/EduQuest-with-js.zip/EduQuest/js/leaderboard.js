/* =============================================================
   EduQuest - leaderboard.js  (used by leaderboard.html)

   Page-specific JavaScript for leaderboard.html goes here,
   including any backend calls this page needs.
============================================================= */
(function () {
    "use strict";
})();
