/* =============================================================
   EduQuest - signupp.js  (used by signupp.html)

   Three-step sign-up: 1) account details, 2) province and school,
   3) subjects. The final submit currently goes straight to the dashboard.
============================================================= */
(function () {
    "use strict";

    /* SAMPLE DATA - this will be replaced by the backend. */
    var schools = {
        "Eastern Cape": ["Example High School - Eastern Cape", "Nelson Mandela High School"],
        "Free State": ["Example High School - Free State", "Mangaung High School"],
        "Gauteng": ["Example High School - Gauteng", "Johannesburg High School", "Pretoria Secondary School", "Soweto High School"],
        "KwaZulu-Natal": ["Example High School - KwaZulu-Natal", "Durban High School"],
        "Limpopo": ["Example High School - Limpopo", "Polokwane High School"],
        "Mpumalanga": ["Example High School - Mpumalanga", "Mbombela High School"],
        "Northern Cape": ["Example High School - Northern Cape", "Kimberley High School"],
        "North West": ["Example High School - North West", "Rustenburg High School"],
        "Western Cape": ["Example High School - Western Cape", "Cape Town High School"]
    };

    function byId(id) {
        return document.getElementById(id);
    }

    function showError(message) {
        var box = byId("error");
        box.textContent = message;
        box.style.display = "block";
    }

    function clearError() {
        byId("error").style.display = "none";
    }

    function showStep(n) {
        clearError();
        document.querySelectorAll(".signup-step").forEach(function (step) {
            step.classList.remove("active");
        });
        byId("s" + n).classList.add("active");

        for (var i = 1; i <= 3; i++) {
            byId("n" + i).classList.toggle("active", i <= n);
        }
        byId("l1").classList.toggle("active", n >= 2);
        byId("l2").classList.toggle("active", n >= 3);

        window.scrollTo({ top: 0, behavior: "smooth" });
    }

    /* Step 1 -> 2: check the account details. */
    function goToStep2() {
        clearError();
        var fields = ["fullName", "email", "grade", "password", "confirmPassword", "terms"];
        for (var i = 0; i < fields.length; i++) {
            var field = byId(fields[i]);
            if (!field.checkValidity()) {
                field.reportValidity();
                return;
            }
        }
        if (byId("password").value !== byId("confirmPassword").value) {
            showError("Passwords do not match.");
            return;
        }
        showStep(2);
    }

    /* Fill the school list for the chosen province.
       TODO (backend): load the schools for the province from the server. */
    function loadSchools() {
        var province = byId("province").value;
        var school = byId("school");
        school.innerHTML = "";

        if (!province) {
            school.disabled = true;
            return;
        }

        school.disabled = false;

        var placeholder = document.createElement("option");
        placeholder.textContent = "Select your school";
        placeholder.value = "";
        placeholder.disabled = true;
        placeholder.selected = true;
        school.appendChild(placeholder);

        schools[province].forEach(function (name) {
            var option = document.createElement("option");
            option.value = name;
            option.textContent = name;
            school.appendChild(option);
        });
    }

    /* Step 2 -> 3: check province and school. */
    function goToStep3() {
        clearError();
        if (!byId("province").value) {
            showError("Please select your province.");
            return;
        }
        if (!byId("school").value) {
            showError("Please select your school.");
            return;
        }
        showStep(3);
    }

    function updateSubjects() {
        var selected = document.querySelectorAll('input[name="subjects"]:checked');
        byId("count").textContent = selected.length + (selected.length === 1 ? " subject selected" : " subjects selected");

        document.querySelectorAll('input[name="subjects"]').forEach(function (input) {
            input.nextElementSibling.querySelector(".subject-status").textContent = input.checked ? "\u2713 Selected" : "Select";
        });
    }

    /* Wire up the page (replaces the old onclick / onchange attributes). */
    byId("step1-next").addEventListener("click", goToStep2);
    byId("step2-back").addEventListener("click", function () { showStep(1); });
    byId("step2-next").addEventListener("click", goToStep3);
    byId("step3-back").addEventListener("click", function () { showStep(2); });
    byId("province").addEventListener("change", loadSchools);

    document.querySelectorAll('input[name="subjects"]').forEach(function (input) {
        input.addEventListener("change", updateSubjects);
    });

    byId("signupForm").addEventListener("submit", function (event) {
        event.preventDefault();
        clearError();

        if (document.querySelectorAll('input[name="subjects"]:checked').length === 0) {
            showError("Please select at least one subject.");
            return;
        }

        /* TODO (backend): create the account here (name, email, grade, password,
           province, school and the chosen subjects) and only continue on success. */
        window.location.href = "dashboard.html";
    });
})();
