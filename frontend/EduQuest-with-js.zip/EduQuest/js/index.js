/* =============================================================
   EduQuest - index.js  (used by index.html)

   Page-specific JavaScript for index.html goes here,
   including any backend calls this page needs.
============================================================= */
(function () {
    "use strict";
})();
