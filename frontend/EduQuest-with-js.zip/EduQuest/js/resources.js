/* =============================================================
   EduQuest - resources.js  (used by resources.html)

   Page-specific JavaScript for resources.html goes here,
   including any backend calls this page needs.
============================================================= */
(function () {
    "use strict";
})();
