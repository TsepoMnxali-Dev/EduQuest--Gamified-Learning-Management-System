/* =============================================================
   EduQuest - accounting-class.js  (used by accounting-class.html)

   Page-specific JavaScript for accounting-class.html goes here,
   including any backend calls this page needs.
============================================================= */
(function () {
    "use strict";
})();
