/* =============================================================
   EduQuest - dashboard.js  (used by dashboard.html)

   Page-specific JavaScript for dashboard.html goes here,
   including any backend calls this page needs.
============================================================= */
(function () {
    "use strict";
})();
