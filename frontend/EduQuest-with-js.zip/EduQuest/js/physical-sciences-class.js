/* =============================================================
   EduQuest - physical-sciences-class.js  (used by physical-sciences-class.html)

   Page-specific JavaScript for physical-sciences-class.html goes here,
   including any backend calls this page needs.
============================================================= */
(function () {
    "use strict";
})();
