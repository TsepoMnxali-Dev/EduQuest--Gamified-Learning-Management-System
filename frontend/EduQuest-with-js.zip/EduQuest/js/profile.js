/* =============================================================
   EduQuest - profile.js  (used by profile.html)

   Page-specific JavaScript for profile.html goes here,
   including any backend calls this page needs.
============================================================= */
(function () {
    "use strict";
})();
