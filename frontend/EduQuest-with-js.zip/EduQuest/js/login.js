/* =============================================================
   EduQuest - login.js  (used by login.html)
============================================================= */
(function () {
    "use strict";

    var form = document.getElementById("loginForm");
    if (!form) { return; }

    form.addEventListener("submit", function (event) {
        event.preventDefault();

        /* TODO (backend): send the sign-in details to the server here,
           then go to dashboard.html on success or show an error message. */
        alert("Login functionality will be connected to the backend later.");
    });
})();
